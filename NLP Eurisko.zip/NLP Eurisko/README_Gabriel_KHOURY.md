Resume Classification Project
Overview
This project involves building a machine learning model to classify resumes into various job categories. The dataset includes resumes with associated categories, and we use data augmentation techniques to enhance the model's performance. The project leverages Hugging Face Transformers and PyTorch for model training and evaluation.

Table of Contents
Project Description
Dataset
Installation
Usage
Training
Evaluation
Data Augmentation
Results
Contributing
License
Project Description
This project aims to classify resumes into predefined job categories using a machine learning model. We preprocess the resume data, tokenize the text using a transformer model, and train a classifier to predict the job categories. Data augmentation is used to increase the diversity of the training dataset.

Dataset
Source: UpdatedResumeDataSet.csv and ahmedheakl/resume-atlas(hugging face)
Description: The dataset consists of resumes labeled with job categories.
Fields:
Resume: The text of the resume.
Category: The job category of the resume.
Data Augmentation: Augmented the dataset from 250 to 500 resumes to enhance model performance.
Installation
Ensure you have Python 3.7+ installed. You can install the required dependencies using pip:

bash
Copy code
pip install -r requirements.txt
Usage
To run the project, follow these steps:

Prepare the Dataset: Ensure that your dataset is in the correct format and located in the specified directory.

Run the Preprocessing Script:

bash
Copy code
python preprocess.py
Train the Model:

bash
Copy code
python train.py
Evaluate the Model:

bash
Copy code
python evaluate.py
Training
The model is trained using Hugging Face Transformers with the following settings:

Model: bert-base-uncased
Epochs: 5
Batch Size: 16
Evaluation Strategy: Epoch-wise evaluation
To modify training parameters, adjust the TrainingArguments in train.py.

Evaluation
The model is evaluated using accuracy as the primary metric. The evaluation script provides performance metrics and insights into model effectiveness.

Data Augmentation
To address data scarcity, the dataset was augmented to double its size. Augmentation methods include:

Results
The model achieved the following performance metrics:

Accuracy: 0.86
We should have stopped at epoch 3 since not much changed and it was starting to overfit